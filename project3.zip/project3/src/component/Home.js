import React, { useState } from 'react'
import { UseAuth } from './Auth' 
import './home.css'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
export default function Home() {
  const auth = UseAuth()
  const[name,setname]=useState('')
  const[email,setemail]=useState('')
  const[message,setmessage]=useState('')
  const navigate=useNavigate()
  const handleMessage=()=>{
    axios.post('http://localhost:3001/Message',{"Name":name,"email":email,"message":message})
  }
  const MovetoUser=()=>{
    if(auth.user){
    navigate('/users')
    }
    else{
      navigate('/login')
    }
  }
  
  return (
    <div className="Home-page">
    <div className="Addfeed">
        <p>User feedback is a valuable tool for businesses and organizations to understand the experiences and opinions of their customers or users. It provides insights into what is working well and what areas need improvement. Constructive feedback is specific, clear, and focuses on the impact of the product or service. It helps in making informed decisions and enhancing the overall user experience.</p>
        <button onClick={MovetoUser}>AddFeedback</button>
       </div>
   <div className="AboutSystem">
       <h1>About</h1>
        <p>
           Welcome to , where we believe in the power of feedback to drive improvement and success. Our feedback management system is designed to help businesses and organizations of all sizes gather valuable insights, engage with their customers or employees, and make data-driven decisions. At [Your Company Name], we understand that feedback is more than just comments or ratings – it's an opportunity to learn, grow, and excel. Our platform offers a user-friendly interface, robust analytics, and customizable features to meet your unique feedback management needs. With our solution, you can collect feedback through various channels, analyze feedback data in real time, engage with stakeholders, and improve decision-making processes based on data-driven feedback. Our team is dedicated to providing exceptional support and guidance every step of the way. Whether you're looking to enhance customer satisfaction, drive employee engagement, or optimize product offerings, we're here to help you succeed. Join us on the journey to harness the power of feedback and unlock new opportunities for growth and innovation. Get started with [] today!
        </p>
   </div>
   <form onSubmit={handleMessage}>
   <div class="Contact">
        <h2>Contact</h2>
        <input type="text" placeholder="Name" value={name} onChange={(e)=>setname(e.target.value)}/>
        <br></br>
        <br></br>
        <br></br>
        <input type="email" placeholder="Email" value={email} onChange={(e)=>setemail(e.target.value)}/>
        <br></br>
        <br></br>
        <br></br>
        <textarea value={message} placeholder='Enter Your Message' onChange={(e)=>setmessage(e.target.value)}></textarea>
        <br></br>
        <br></br>
        <br></br>
        <button type='submit'>Send</button>
   </div>
   </form>

</div>
  )
}
